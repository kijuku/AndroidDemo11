package com.main.myshoppingdatabase;

public enum Values {
    DATE,
    DOWNWARDS,
    UPWARDS

}
